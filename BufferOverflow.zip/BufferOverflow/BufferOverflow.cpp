// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

int main()
#include <iomanip>
#include <iostream>
{
    // Display a message indicating the start of the program
    std::cout << "Buffer Overflow Example" << std::endl;

    // Define a constant account number
    const std::string account_number = "CharlieBrown42";

    // Declare a string to s
    // tore user input
    std::string user_input;  // Use std::string for user input

    // Prompt the user to enter a value
    std::cout << "Enter a value: ";

    // Read user input using std::getline to handle spaces and newlines
    std::getline(std::cin, user_input);  // Use std::getline for input

    // Limit input length to 20 characters
    if (user_input.length() > 20) {
        user_input = user_input.substr(0, 20);  // Truncate input if longer than 20 characters
    }

    // Display the user's entered input
    std::cout << "You entered: " << user_input << std::endl;

    // Display the constant account number
    std::cout << "Account Number = " << account_number << std::endl;

    // Program execution ends
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
