// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom exception occurred";
    }
};

bool do_even_more_custom_application_logic()
{
    throw std::logic_error("Standard exception occurred");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    try
    {
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }

    try
    {
        throw CustomException();
    }
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught: " << e.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    if (den == 0)
    {
        throw std::runtime_error("Divide by zero error occurred");
    }

    return (num / den);
}

void do_division() noexcept
{
    try
    {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }
}

int main()
{
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        std::cerr << "Custom Exception caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Unhandled exception caught in main." << std::endl;
    }

    std::cout << "Exceptions Tests completed!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
